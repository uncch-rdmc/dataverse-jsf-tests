Geographic data: NC Research Triangle locations.
