Playwright test archive
This is a sample ZIP file.
