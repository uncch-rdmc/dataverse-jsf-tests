Outer zip containing an inner zip.
